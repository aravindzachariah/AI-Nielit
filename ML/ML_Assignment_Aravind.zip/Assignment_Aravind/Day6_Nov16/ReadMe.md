# Question1
Develop an ML model for predicting the digits in the digits image dataset in
sklearn using SVM . Plot some sample input images together with its class
information. Also plot some predicted outputs together with its actual
images.
[hint: To plot the images using plt.imshow use the actual dimension of the
images in the dataset. Before fitting the data to the SVC model reshape the
X data from (n,8,8) to (n, 64) using X.reshape(n,-1) where n is the number of
images]
![Screenshot](q1.png) 
```
q1.py
```

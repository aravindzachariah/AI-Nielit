student<-list("Aravind",12,"Male",c(45,46,50))
student
dimnames(student)<-c("Name","RollNumber","Gender","Marks")

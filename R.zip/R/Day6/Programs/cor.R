X<-c(7,6,8,5,6,9)
Y<-c(12,8,12,10,11,13)
cor(X,Y)
cor(X, Y , method = "spearman")
cor(X, Y , method = "kendall")


?cor



X<-c(10,8,2,1,5,6)
Y<-c(2,3,9,7,6,5)
cor(X,Y)






roll=c(10,11,12)
sname=c("Anitha","Mini","Biju")
pass=c(TRUE,FALSE,TRUE)
student1=data.frame(roll,sname,pass)



#roll=c(13,14,15)
#sname=c("Anu","Minu","Biji")
#pass=c(TRUE,FALSE,TRUE)
#student2=data.frame(roll,sname,pass)

#rbind(student1,student2)
#d=data.frame(cbind(student1,student2))

#row.names(d)=c("one","two","three")
ls()
list.files()
save.image() 
rm(list=ls())
load(".RData")



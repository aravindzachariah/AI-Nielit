3*4
(8/2-(3*4))
8/(2-3)*4
x<-1:20
y<-20:1

label<-"label"
num<-1:30
paste(label,num)

str1<-"The quick brown fox jumps over the lazy dog"
sub('brown','red',str1)

#substr(str1,14,nchar('fox'))
substr(str1,17,19)

p<-2*(3+4)
?rep()
#rep(1:4,c(2,1,2,1))
#rep(1:4, each=2, len=10)
rep(c(4,6,3), each=1, times=10)